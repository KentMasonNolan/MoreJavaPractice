public class Person {

    public String name;

    public String interest;

    public String favBook;

    public String favFilm;

    public String dateOfBirth;

}
