package Week4;

public class MultiSphere {

    public static void main(String[] args){
        System.out.println("test");

        Sphere s1 = new Sphere(12);
        Sphere s2 = new Sphere(10);
        Sphere s3 = new Sphere(43);
        Sphere s4 = new Sphere(1);
        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);
    }
}
