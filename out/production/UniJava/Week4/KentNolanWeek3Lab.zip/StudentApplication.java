package Week4;


public class StudentApplication {

    public static void main(String[] args) {
        Student aStudent = new Student("Justin","Case","01234");
        System.out.println(aStudent);
    }
}